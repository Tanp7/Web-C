//退出登入
// var logout = function(){
	// swal({
		// title:login_name,
		// text:'确实要退出吗？',
		// icon:'info',
		// closeOnClickOutside:true,
		// closeOnEsc:true,
		// buttons:['取消','确定']
	// }).then(function(value){
		// if(value==null)
			// return;
		// jqu.loadJson('/admin/logout.do',function(result){
			// location.href='/admin';
		// });
	// });
// };

$(function(){
	
});