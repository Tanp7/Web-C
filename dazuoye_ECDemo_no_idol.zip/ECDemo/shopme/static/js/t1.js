
$(function(){
	alert('ddd');
});