#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Author   :


filename = 'aa.bb.cc.jpg'
fileext = filename.split('.')[-1]
print(fileext)
	