var f1 = function(){
	swal({
			title:'测试标题',
			text:'。。。。文本',
			icon:'info',
			buttons:'确定'
		});
};

$(function(){
	
		
});