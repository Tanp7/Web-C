function myFunction()
{
    document.getElementById("demo").innerHTML="我的第二个 JavaScript 函数";
}