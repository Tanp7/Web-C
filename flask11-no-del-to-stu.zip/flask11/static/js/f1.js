
var play = function(){
	$('#i1').addClass('fa-spin');
};

var stop = function(){
	$('#i1').removeClass('fa-spin');
};